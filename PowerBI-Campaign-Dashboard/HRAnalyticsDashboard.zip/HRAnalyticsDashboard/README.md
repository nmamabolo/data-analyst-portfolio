# HR Analytics Dashboard

A seven-page Power BI Project portfolio package with synthetic HR data, icon-led KPI cards, and a semantic color system.

## Open
1. Extract the complete folder.
2. Run **Open-HRAnalyticsDashboard.ps1**.
3. Power BI Desktop opens the PBIP and loads the included workbook.

## Pages
1. HR Executive Overview
2. Workforce & Diversity
3. Recruitment
4. Retention & Turnover
5. Attendance & Leave
6. Performance & Development
7. Compensation & Cost

All people, compensation, and organizational records are fictional. Production implementations should use row-level security for sensitive information.
